package com.mohammedalfateh.mustawda

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.BitmapFactory
import android.widget.ImageView
import android.view.ViewGroup
import android.widget.FrameLayout
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // A real PNG ornament sits around the WebView. The original HTML remains untouched.
        val outerFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(5, 24, 20))
        }

        webView = WebView(this)
        val contentInset = dp(18)
        outerFrame.addView(
            webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ).apply {
                setMargins(contentInset, contentInset, contentInset, contentInset)
            }
        )

        val frameBitmap = assets.open("outer_frame.png").use { BitmapFactory.decodeStream(it) }
        val frameImage = ImageView(this).apply {
            setImageBitmap(frameBitmap)
            scaleType = ImageView.ScaleType.FIT_XY
            isClickable = false
            isFocusable = false
            contentDescription = null
        }
        outerFrame.addView(
            frameImage,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(outerFrame)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.settings.setSupportMultipleWindows(false)
        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        webView.webChromeClient = WebChromeClient()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                val scheme = url.scheme ?: ""
                if (scheme == "http" || scheme == "https" || scheme == "whatsapp" || scheme == "tg") {
                    if (url.host == "wa.me" || url.host == "api.whatsapp.com" ||
                        url.host == "t.me" || scheme == "whatsapp" || scheme == "tg") {
                        return openExternal(url)
                    }
                    if (url.host != null && !url.host!!.contains("jsdelivr.net")) {
                        return openExternal(url)
                    }
                }
                return false
            }

            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                val uri = Uri.parse(url)
                if (uri.scheme == "http" || uri.scheme == "https" ||
                    uri.scheme == "whatsapp" || uri.scheme == "tg") {
                    if (uri.host == "wa.me" || uri.host == "api.whatsapp.com" ||
                        uri.host == "t.me" || uri.scheme == "whatsapp" || uri.scheme == "tg") {
                        return openExternal(uri)
                    }
                }
                return false
            }
        }

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    private fun createDecorativeFrame(): LayerDrawable {
        val outer = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(10, 48, 39), Color.rgb(20, 75, 56), Color.rgb(7, 39, 33))
        ).apply {
            cornerRadius = dp(12).toFloat()
            setStroke(dp(3), Color.rgb(201, 164, 83))
        }

        val inner = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = dp(8).toFloat()
            setStroke(dp(1), Color.rgb(137, 111, 57))
        }

        return LayerDrawable(arrayOf(outer, inner)).apply {
            setLayerInset(1, dp(5), dp(5), dp(5), dp(5))
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun openExternal(uri: Uri): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
